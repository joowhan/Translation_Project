from high2low import Changer_low as ch_low
import is_horl as is_horl
#from isHighlow import Checker_hl as checker

txt = input("Enter Korean Sentence: ")

hi = is_horl.isHigh()
detect=hi.isThisHigh(txt)
if detect == 0:
    print("다음 문장은 반말입니다. 문장이 변경되지 않습니다.")
elif detect ==1:
    print("다음 문장은 높임말입니다. 문장을 반말로 변경합니다.")
else:
    print("제대로 판별하지 못했습니다.")
    
ch = ch_low()

output = ch.processText(txt)
print("Converted Result:", output)
